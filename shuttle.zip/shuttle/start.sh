#!/usr/bin/env bash
nohup ./shuttle >> shuttle.log 2>&1 &
